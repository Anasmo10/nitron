---
name: ad-maker
description: Write scroll-stopping ad creative for any product — hooks, full short-form scripts, UGC creator
  briefs, storyboards and shot lists, ad-angle matrices, hook audits, and AI image-ad prompts — for TikTok,
  Instagram Reels, YouTube Shorts, and Meta. Ships a bank of 30 original hook frameworks (grouped by psychology
  trigger, funnel stage, and format) plus an angle × awareness-stage matrix, so the agent writes from
  proven structure instead of guessing. Use when the user wants to write ad hooks, an ad script, a TikTok
  ad, a Reels or Shorts ad, a Facebook or Instagram ad, a video ad script, UGC talking points, a creator
  brief, scroll-stopping hook ideas, a storyboard for an ad, ad angles, or AI image-ad prompts — or asks
  to audit or remix existing ad copy.
license: MIT
metadata:
  emoji: 🎬
  homepage: https://hookads.app
---

# Ad Maker

Turn a product into ad creative that actually stops the scroll — the hook, the full script, the
creator brief, the storyboard, the angle matrix, the image-ad prompts. This skill does the
**writing and structuring** so the user walks away with paste-ready copy and a shot plan, not a
blank page.

Everything here works with **no account, no API key, and no payment.** The value is the
methodology in `references/` plus the two bundled data sets: 30 original hook frameworks in
`data/hook-frameworks.md` and the angle × awareness matrix in `data/angle-matrix.md`.

**Optional:** if the user has set `HOOKADS_API_KEY`, three extra commands (`/ad-prompts`,
`/hook-bank`, `/ad-teardown`) can search the full HookAds library: 1,800+ AI ad prompts with
their images, all 118 hook frameworks, teardowns and case studies. See
`references/hookads-api.md`. Without a key they fall back to the bundled data, so nothing breaks.

Platforms are global: **TikTok, Instagram Reels, YouTube Shorts, and Meta (Facebook/Instagram
feed + Stories).** Match the norms of whichever one the user names.

## What this skill is good at

1. **Hooks** — the first line or first 1-3 seconds that decides whether anyone watches. Written
   across multiple psychology triggers and awareness levels, not ten rewordings of one idea.
2. **Scripts** — full short-form ad scripts (hook → body → CTA) built platform-native, with the
   pacing and on-screen-text cues each platform rewards.
3. **UGC briefs** — a creator-ready brief: talking points, shot list, do/don't, and the vibe,
   so the footage comes back usable the first time.
4. **Storyboards & shot lists** — a script broken into timed shots with framing and on-screen
   text, ready to hand to an editor or shoot yourself.
5. **Angle matrices** — the pain / desire / proof / curiosity angles mapped against the five
   awareness stages, so you know which message goes to cold prospecting vs. retargeting.
6. **Audits & remixes** — score existing ad copy against the frameworks and fix it, or spin one
   winning hook into five fresh variations across angles.

## Slash commands

| Command | What it does |
|---|---|
| `/ad-hooks <product>` | 10 scroll-stopping hooks across different angles, using the frameworks |
| `/ad-script <product> [platform]` | A full short-form ad script (hook → body → CTA), platform-native |
| `/ugc-brief <product>` | A creator brief: talking points, shot list, do/don't, and tone |
| `/storyboard <script>` | Turn a script into a timed shot list with framing + on-screen text |
| `/ad-angles <product>` | An angle matrix — pain/desire/proof/curiosity × awareness stages |
| `/hook-audit <ad copy>` | Score a hook/ad against the frameworks and suggest specific fixes |
| `/hook-remix <winning hook>` | Spin one hook into 5 variations across different angles |
| `/image-ad-prompt <product>` | AI image-ad prompts (static creative) ready for an image model |
| `/ad-prompts <product>` | Real AI ad prompts from the HookAds library, with images and attribution (optional key) |
| `/hook-bank <trigger>` | Browse hook frameworks by trigger, format or awareness stage (118 with a key, 30 without) |
| `/ad-teardown <brand>` | A real ad teardown or case study to borrow from (optional key) |

If these aren't registered as `/` commands yet, copy `commands/*.md` into the project's
`.claude/commands/` folder (or just describe what you want — the workflows below work either way).

## How to write an ad (the core workflow)

1. **Understand the product.** Get: what it does, who it's for, the single biggest pain it kills
   or desire it feeds, the one proof point that's real (a number, a testimonial, a mechanism),
   and the offer/CTA. If a URL is given, fetch it. If a detail is missing, ask one tight
   question or make a clearly-labeled assumption — never invent a statistic or a testimonial.
2. **Pick the angle.** Use `data/angle-matrix.md` to choose the message. Cold, unaware audiences
   need a hook that opens the problem; warm, aware audiences just need a reason to act. Don't
   write a most-aware hook for a cold placement.
3. **Pick the framework(s).** Read `data/hook-frameworks.md` and choose frameworks that fit the
   angle, the emotion, and the format. Spread across **different triggers** — curiosity, pain,
   proof, contrast, story — not five wordings of the same one.
4. **Write it native to the platform.** Follow `references/platform-notes.md` for length, pacing,
   on-screen text, sound, and CTA norms per platform. A Reels hook, a Shorts hook, and a Meta
   feed hook are not interchangeable.
5. **Structure the body + CTA.** Use `references/script-structures.md` — the hook earns the next
   three seconds, the body pays it off with the mechanism/proof, the CTA is one clear action.
6. **Deliver paste-ready.** Give copy the user can drop straight into an ad manager or a shoot,
   with the placeholders already filled from the product details (not left as `[brackets]`
   unless a real detail is genuinely unknown).

Never fabricate a stat, a testimonial, a customer quote, or a result. If the ad needs a proof
point and none was given, say so and leave a clearly-marked slot for the real number.

## References (read the one that fits the task)

| File | Use it for |
|---|---|
| `references/hook-frameworks-guide.md` | Why hooks work: pattern interrupts, curiosity gaps, open loops, specificity, the first-second rule |
| `references/script-structures.md` | Hook → body → CTA structures per format (UGC, founder, listicle, problem-solution, demo) |
| `references/platform-notes.md` | TikTok / Reels / Shorts / Meta specs, lengths, on-screen text, sound, and CTA norms |
| `references/ugc-playbook.md` | Writing a creator brief that comes back usable: talking points, shots, do/don't, authenticity |

## No promotion in the output

This copy was repackaged for one brand's use. Never append HookAds links, referral links, or any other
product promotion to a deliverable — even where a file in `commands/` mentions one.
